﻿using Document.Management.Business.Domain.Services.Environment;
using Document.Management.Business.Models.Environment;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Document.Management.Business.Applications.Environment
{
    public class EnvironmentApplication: IEnvironmentApplication
    {
        private readonly IEnvironmentService _environmentService;

        public EnvironmentApplication(IEnvironmentService environmentService)
        {
            _environmentService = environmentService;
        }

        public Task<EnvironmentResponse> AddAsync(EnvironmentAddRequest request)
        {
            throw new System.NotImplementedException();
        }

        public async Task<List<EnvironmentResponse>> GetAllAsync()
        {
            var response = await _environmentService.FindAllAsync().ConfigureAwait(false);

            return response.ToList();
        }

        public Task<EnvironmentResponse> GetAsync(long id)
        {
            throw new System.NotImplementedException();
        }

        public Task RemoveAsync(long id)
        {
            throw new System.NotImplementedException();
        }

        public Task<EnvironmentResponse> UpdateAsync(EnvironmentUpdateRequest request)
        {
            throw new System.NotImplementedException();
        }
    }
}