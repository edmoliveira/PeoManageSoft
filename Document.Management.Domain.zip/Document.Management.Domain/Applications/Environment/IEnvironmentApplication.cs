﻿using Document.Management.Business.Applications.Interfaces;
using Document.Management.Business.Models.Environment;

namespace Document.Management.Business.Applications.Environment
{
    public interface IEnvironmentApplication: IBaseApplication<EnvironmentAddRequest, EnvironmentUpdateRequest, EnvironmentResponse>
    {
    }
}
