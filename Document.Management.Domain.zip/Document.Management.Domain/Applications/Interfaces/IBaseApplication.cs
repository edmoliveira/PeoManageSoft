﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Document.Management.Business.Applications.Interfaces
{
    public interface IBaseApplication<TAddRequest, TUpdateRequest, TResponse>
    {
        Task<TResponse> AddAsync(TAddRequest request);
        Task<TResponse> UpdateAsync(TUpdateRequest request);
        Task RemoveAsync(long id);
        Task<TResponse> GetAsync(long id);
        Task<List<TResponse>> GetAllAsync();
    }
}
