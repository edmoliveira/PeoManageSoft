﻿using Document.Management.Business.Domain.Services.User;
using Document.Management.Business.Infrastructure.Helpers.Extensions;
using Document.Management.Business.Infrastructure.Helpers.Interfaces;
using Document.Management.Business.Models.User;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;

namespace Document.Management.Business.Applications.User
{
    public class AuthenticationApplication: IAuthenticationApplication
    {
        private readonly IUserService _service;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly ITokenJwt _tokenJwt;
        /// <summary>
        /// Application Configuration
        /// </summary>
        private readonly IAppConfig _appConfig;
        /// <summary>
        /// Log
        /// </summary>
        private readonly ILogger<AuthenticationApplication> _logger;

        public AuthenticationApplication(IUserService service, IHttpContextAccessor httpContextAccessor, ITokenJwt tokenJwt, IAppConfig appConfig, ILogger<AuthenticationApplication> logger)
        {
            _service = service;
            _httpContextAccessor = httpContextAccessor;
            _tokenJwt = tokenJwt;
            _appConfig = appConfig;
            _logger = logger;
        }

        public async Task<AuthenticateResponse> AuthenticateAsync(AuthenticateRequest request)
        {
            string methodName = nameof(AuthenticateAsync);

            _logger.LogBeginInformation(methodName);

            AuthenticateResponse authenticateResponse = new AuthenticateResponse();

            UserResponse userResponse = await _service.FindUserAsync(request.User, request.Password).ConfigureAwait(false);

            if (userResponse != null)
            {
                UserSessionResponse userSessionResponse = await CreateToken(userResponse).ConfigureAwait(false); ;

                authenticateResponse.IsAuthenticated = userSessionResponse.IsAuthenticated;
                authenticateResponse.Data = userSessionResponse.Data;
            }
            else
            {

                authenticateResponse.IsAuthenticated = false;
                authenticateResponse.ErrorMessage = "Not authorized";
            }

            _logger.LogEndInformation(methodName);

            return authenticateResponse;
        }

        public async Task<UserSessionResponse> SaveUserSessionAsync()
        {
            string methodName = nameof(SaveUserSessionAsync);

            _logger.LogBeginInformation(methodName);

            UserSessionResponse response = new UserSessionResponse { IsAuthenticated = false };

            IIdentity identity = _httpContextAccessor.HttpContext.User.Identity;

            if (identity.IsAuthenticated)
            {
                UserResponse userResponse = await _service.FindUserAsync(identity.Name).ConfigureAwait(false);

                if (userResponse != null)
                {
                    response = await CreateToken(userResponse).ConfigureAwait(false);
                }
            }

            _logger.LogEndInformation(methodName);

            return response;
        }

        private async Task<UserSessionResponse> CreateToken(UserResponse user, DateTime? expires = null)
        {
            string methodName = nameof(CreateToken);

            _logger.LogBeginInformation(methodName);

            if (!expires.HasValue)
            {
                expires = DateTime.UtcNow.AddSeconds(_appConfig.AuthTokenExpireSeconds);
            }

            ClaimsIdentity claimsIdentity = new ClaimsIdentity(new Claim[]
            {
                    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                    new Claim(ClaimTypes.Name, user.User),
                    new Claim(ClaimTypes.Role, user.Role.ToString())
            });

            string token = await _tokenJwt.CreateTokenAsync(claimsIdentity, expires.Value).ConfigureAwait(false);

            UserSessionResponse response = new UserSessionResponse
            {
                IsAuthenticated = true,
                Data = new UserData
                {
                    Key = token,
                    ExpireSeconds = _appConfig.AuthTokenExpireSeconds,
                    Role = user.Role,
                    ShortName = user.ShortName
                }
            };

            _logger.LogEndInformation(methodName);

            return response;
        }
    }
}
