﻿using Document.Management.Business.Models.User;
using System.Threading.Tasks;

namespace Document.Management.Business.Applications.User
{
    public interface IAuthenticationApplication
    {
        Task<AuthenticateResponse> AuthenticateAsync(AuthenticateRequest request);
        Task<UserSessionResponse> SaveUserSessionAsync();
    }
}
