﻿using Document.Management.Business.Applications.Interfaces;
using Document.Management.Business.Models.User;
using System.Threading.Tasks;

namespace Document.Management.Business.Applications.User
{
    public interface IUserApplication : IBaseApplication<UserAddRequest, UserUpdateRequest, UserResponse>
    {
        Task<ChangePasswordResponse> ChangePasswordAsync(ChangePasswordRequest request);
    }
}
