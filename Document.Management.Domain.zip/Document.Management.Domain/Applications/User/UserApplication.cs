﻿using Document.Management.Business.Domain.Services.User;
using Document.Management.Business.Infrastructure.Helpers.Extensions;
using Document.Management.Business.Models.User;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Document.Management.Business.Applications.User
{
    public class UserApplication : IUserApplication
    {
        private readonly IUserService _service;
        /// <summary>
        /// Log
        /// </summary>
        private readonly ILogger<UserApplication> _logger;

        public UserApplication(IUserService service, ILogger<UserApplication> logger)
        {
            _service = service;
            _logger = logger;
        }

        public async Task<UserResponse> AddAsync(UserAddRequest request)
        {
            string methodName = nameof(AddAsync);

            _logger.LogBeginInformation(methodName);

            UserResponse response = await _service.AddAsync(request).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return response;
        }

        public async Task<List<UserResponse>> GetAllAsync()
        {
            string methodName = nameof(GetAllAsync);

            _logger.LogBeginInformation(methodName);

            IEnumerable<UserResponse> response = await _service.FindAllAsync().ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return response.ToList();
        }

        public async Task<UserResponse> GetAsync(long id)
        {
            string methodName = nameof(GetAsync);

            _logger.LogBeginInformation(methodName);

            UserResponse response = await _service.FindByIdAsync(id).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return response;
        }

        public async Task RemoveAsync(long id)
        {
            string methodName = nameof(RemoveAsync);

            _logger.LogBeginInformation(methodName);

            await _service.RemoveAsync(id).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);
        }

        public async Task<UserResponse> UpdateAsync(UserUpdateRequest request)
        {
            string methodName = nameof(UpdateAsync);

            _logger.LogBeginInformation(methodName);

            UserResponse response = await _service.UpdateAsync(request).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return response;
        }

        public async Task<ChangePasswordResponse> ChangePasswordAsync(ChangePasswordRequest request)
        {
            string methodName = nameof(UpdateAsync);

            _logger.LogBeginInformation(methodName);

            bool response = await _service.ChangePasswordAsync(request.User, request.OldPassword, request.NewPassword).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return new ChangePasswordResponse
            {
                WasChanged = response,
                ErrorMessage = !response ? "No user can be found for this username/old password combination" : null
            };
        }
    }
}
