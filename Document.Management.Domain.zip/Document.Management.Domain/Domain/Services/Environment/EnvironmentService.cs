﻿using AutoMapper;
using Document.Management.Business.Infrastructure.Helpers.Extensions;
using Document.Management.Business.Infrastructure.ObjectRelationalMapper;
using Document.Management.Business.Infrastructure.Repositories.Environment;
using Document.Management.Business.Models.Environment;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Document.Management.Business.Domain.Services.Environment
{
    public sealed class EnvironmentService : IEnvironmentService
    {
        private readonly ITransactionScope _transactionScope;
        private readonly IEnvironmentRepository _repository;
        private readonly IMapper _mapper;
        /// <summary>
        /// Log
        /// </summary>
        private readonly ILogger<EnvironmentService> _logger;

        public EnvironmentService(ITransactionScope transactionScope, IEnvironmentRepository repository, IMapper mapper, ILogger<EnvironmentService> logger)
        {
            _transactionScope = transactionScope;
            _repository = repository;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<EnvironmentResponse> AddAsync(EnvironmentAddRequest request)
        {
            string methodName = nameof(AddAsync);

            _logger.LogBeginInformation(methodName);

            EnvironmentResponse result = await _transactionScope.UsingAsync(async scope =>
            {
                EnvironmentEntity entity = _mapper.Map<EnvironmentEntity>(request);

                await _repository.InsertAsync(scope, entity).ConfigureAwait(false);

                return _mapper.Map<EnvironmentResponse>(entity);
            }).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }

        public async Task<IEnumerable<EnvironmentResponse>> FindAllAsync()
        {
            string methodName = nameof(FindAllAsync);

            _logger.LogBeginInformation(methodName);

            IEnumerable<EnvironmentResponse> result = await _transactionScope.UsingAsync(async scope =>
            {
                IEnumerable<EnvironmentEntity> entities = await _repository.SelectAllAsync(scope).ConfigureAwait(false);

                return _mapper.Map<IEnumerable<EnvironmentResponse>>(entities);
            }).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }

        public async Task<EnvironmentResponse> FindByIdAsync(long id)
        {
            string methodName = nameof(FindByIdAsync);

            _logger.LogBeginInformation(methodName);

            EnvironmentResponse result = await _transactionScope.UsingAsync(async scope =>
            {
                EnvironmentEntity entity = await _repository.SelectByIdAsync(scope, id).ConfigureAwait(false);

                return _mapper.Map<EnvironmentResponse>(entity);
            }).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }

        public async Task RemoveAsync(long id)
        {
            string methodName = nameof(RemoveAsync);

            _logger.LogBeginInformation(methodName);

            await _transactionScope.UsingAsync(async scope =>
            {
                await _repository.DeleteAsync(scope, id).ConfigureAwait(false);
            }).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);
        }

        public async Task<EnvironmentResponse> UpdateAsync(EnvironmentUpdateRequest request)
        {
            string methodName = nameof(UpdateAsync);

            _logger.LogBeginInformation(methodName);

            EnvironmentResponse result = await _transactionScope.UsingAsync(async scope =>
            {
                EnvironmentEntity entity = _mapper.Map<EnvironmentEntity>(request);

                await _repository.UpdateAsync(scope, entity).ConfigureAwait(false);

                return _mapper.Map<EnvironmentResponse>(entity);
            }).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }
    }
}