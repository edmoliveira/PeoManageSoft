﻿using Document.Management.Business.Domain.Services.Interfaces;
using Document.Management.Business.Models.Environment;

namespace Document.Management.Business.Domain.Services.Environment
{
    public interface IEnvironmentService : IBaseService<EnvironmentAddRequest, EnvironmentUpdateRequest, EnvironmentResponse>
    {
    }
}
