﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Document.Management.Business.Domain.Services.Interfaces
{
    public interface IBaseService<TAddRequest, TUpdateRequest, TResponse>
    {
        Task<TResponse> AddAsync(TAddRequest request);
        Task<TResponse> UpdateAsync(TUpdateRequest request);
        Task RemoveAsync(long id);
        Task<TResponse> FindByIdAsync(long id);
        Task<IEnumerable<TResponse>> FindAllAsync();
    }
}
