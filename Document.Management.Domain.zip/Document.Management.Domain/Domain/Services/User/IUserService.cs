﻿using Document.Management.Business.Domain.Services.Interfaces;
using Document.Management.Business.Models.User;
using System.Threading.Tasks;

namespace Document.Management.Business.Domain.Services.User
{
    public interface IUserService : IBaseService<UserAddRequest, UserUpdateRequest, UserResponse>
    {
        Task<UserResponse> FindUserAsync(string username, string password = null);
        Task<bool> ChangePasswordAsync(string username, string oldPassword, string newPassword);
    }
}
