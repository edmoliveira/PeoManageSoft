﻿using AutoMapper;
using Document.Management.Business.Infrastructure.Helpers.Extensions;
using Document.Management.Business.Infrastructure.ObjectRelationalMapper;
using Document.Management.Business.Infrastructure.Repositories.User;
using Document.Management.Business.Models.User;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Document.Management.Business.Domain.Services.User
{
    public sealed class UserService : IUserService
    {
        private readonly ITransactionScope _transactionScope;
        private readonly IUserRepository _repository;
        private readonly IMapper _mapper;
        /// <summary>
        /// Log
        /// </summary>
        private readonly ILogger<UserService> _logger;

        public UserService(ITransactionScope transactionScope, IUserRepository repository, IMapper mapper, ILogger<UserService> logger)
        {
            _transactionScope = transactionScope;
            _repository = repository;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<UserResponse> AddAsync(UserAddRequest request)
        {
            string methodName = nameof(AddAsync);

            _logger.LogBeginInformation(methodName);

            UserResponse result = await _transactionScope.UsingAsync(async scope =>
            {
                UserEntity entity = _mapper.Map<UserEntity>(request);

                await _repository.InsertAsync(scope, entity).ConfigureAwait(false);

                return _mapper.Map<UserResponse>(entity);
            }).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }

        public async Task<IEnumerable<UserResponse>> FindAllAsync()
        {
            string methodName = nameof(FindAllAsync);

            _logger.LogBeginInformation(methodName);

            IEnumerable<UserResponse> result = await _transactionScope.UsingAsync(async scope =>
            {
                IEnumerable<UserEntity> entities = await _repository.SelectAllAsync(scope).ConfigureAwait(false);

                return _mapper.Map<IEnumerable<UserResponse>>(entities);
            }).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }

        public async Task<UserResponse> FindByIdAsync(long id)
        {
            string methodName = nameof(FindByIdAsync);

            _logger.LogBeginInformation(methodName);

            UserResponse result = await _transactionScope.UsingAsync(async scope =>
            {
                UserEntity entity = await _repository.SelectByIdAsync(scope, id).ConfigureAwait(false);

                return _mapper.Map<UserResponse>(entity);
            }).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }

        public async Task<UserResponse> FindUserAsync(string username, string password = null)
        {
            string methodName = nameof(FindUserAsync);

            _logger.LogBeginInformation(methodName);

            UserResponse result = await _transactionScope.UsingAsync(async scope =>
            {
                UserEntity entity = await _repository.SelectUserAsync(scope, username, password).ConfigureAwait(false);

                return _mapper.Map<UserResponse>(entity);
            }).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }

        public async Task RemoveAsync(long id)
        {
            string methodName = nameof(RemoveAsync);

            _logger.LogBeginInformation(methodName);

            await _transactionScope.UsingAsync(async scope =>
            {
                await _repository.DeleteAsync(scope, id).ConfigureAwait(false);
            }).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);
        }

        public async Task<UserResponse> UpdateAsync(UserUpdateRequest request)
        {
            string methodName = nameof(UpdateAsync);

            _logger.LogBeginInformation(methodName);

            UserResponse result = await _transactionScope.UsingAsync(async scope =>
            {
                UserEntity entity = _mapper.Map<UserEntity>(request);

                await _repository.UpdateAsync(scope, entity).ConfigureAwait(false);

                return _mapper.Map<UserResponse>(entity);
            }).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }

        public async Task<bool> ChangePasswordAsync(string username, string oldPassword, string newPassword)
        {
            string methodName = nameof(ChangePasswordAsync);

            _logger.LogBeginInformation(methodName);

            bool result = await _transactionScope.UsingAsync(async scope =>
                await _repository.ChangePasswordAsync(scope, username, oldPassword, newPassword).ConfigureAwait(false)
            ).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }
    }
}