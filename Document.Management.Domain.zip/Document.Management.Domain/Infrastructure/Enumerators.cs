﻿namespace Document.Management.Business.Infrastructure
{
    public enum UserRole
    {
        Admin = 1,
        User = 2
    }
}
