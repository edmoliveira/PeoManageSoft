﻿using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Document.Management.Business.Infrastructure.Helpers.Attributes
{
    public class AuthorizeRolesAttribute : AuthorizeAttribute
    {
        public AuthorizeRolesAttribute(params UserRole[] roles)
        {
            IEnumerable<string> allowedRolesAsStrings = roles.Select(x => Enum.GetName(typeof(UserRole), x));

            Roles = string.Join(",", allowedRolesAsStrings);
        }
    }
}
