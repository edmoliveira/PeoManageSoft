﻿using AutoMapper;
using Document.Management.Business.Applications.Environment;
using Document.Management.Business.Applications.User;
using Document.Management.Business.Domain.Services.Environment;
using Document.Management.Business.Domain.Services.User;
using Document.Management.Business.Infrastructure.Helpers.Exceptions;
using Document.Management.Business.Infrastructure.Helpers.Extensions;
using Document.Management.Business.Infrastructure.Helpers.Filters;
using Document.Management.Business.Infrastructure.Helpers.Interfaces;
using Document.Management.Business.Infrastructure.ObjectRelationalMapper;
using Document.Management.Business.Infrastructure.Repositories.Environment;
using Document.Management.Business.Infrastructure.Repositories.User;
using Document.Management.Business.Infrastructure.Tokens;
using Document.Management.Business.Models.Environment;
using Document.Management.Business.Models.User;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using System;

namespace Document.Management.Business.Infrastructure.Helpers
{
    public static class DependencyGroupServiceCollection
    {
        public static void AddDependencyGroup(this IServiceCollection services, IConfiguration configuration, string allowSpecificOrigins, Version apiVersion, Type loggerType)
        {
            AppConfig appConfig = configuration.GetSection("AppConfig").Get<AppConfig>();

            services.AddScoped<IApplicationContext, ApplicationContext>();
            services.AddScoped(c => (ISetApplicationContext)c.GetService<IApplicationContext>());

            AddMapperConfiguration(services);

            services.AddControllers();
            services.AddHttpContextAccessor();

            services.AddScoped<IDbContext, DbContext>();
            services.AddScoped<IContentScope, ScopeOrm>();
            services.AddScoped<ITransactionScope, TransactionScopeOrm>();

            services.AddSingleton<IAppConfig>(c => appConfig);

            AddApplicationServices(services);
            AddDomainServices(services);
            AddRepositoryServices(services);

            services.AddSwaggerGen(c =>
            {
                c.EnableAnnotations();
                c.OperationFilter<HeaderParameterOperationFilter>();

                if (!appConfig.WidowsAuthentication)
                {
                    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                    {
                        Description = "JWT Authorization header using the Bearer scheme.",
                        Name = "Authorization",
                        In = ParameterLocation.Header,
                        Type = SecuritySchemeType.ApiKey,
                        Scheme = "bearer"
                    });
                }

                foreach (IConfigurationOpenApiInfo item in appConfig.Documents)
                {
                    c.SwaggerDoc(item.DocumentName, new OpenApiInfo
                    {
                        Version = apiVersion.ToString(2),
                        Title = item.Title,
                        Description = item.Description,
                        TermsOfService = new Uri(appConfig.TermsOfServiceOpenApi),
                        Contact = new OpenApiContact
                        {
                            Name = appConfig.NameOpenApiContact,
                            Email = appConfig.EmailOpenApiContact,
                            Url = new Uri(appConfig.UrlOpenApiContact),
                        },
                        License = new OpenApiLicense
                        {
                            Name = appConfig.NameOpenApiLicense,
                            Url = new Uri(appConfig.UrlOpenApiLicense),
                        }
                    });
                }
            });
            services.AddSwaggerGenNewtonsoftSupport();

            JsonConvert.DefaultSettings = () => new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            };

            services.AddMvcCore(options => options.EnableEndpointRouting = false)
                    .AddCors(options =>
                    {
                        options.AddPolicy(name: allowSpecificOrigins,
                                          builder =>
                                          {
                                              builder
                                                .WithMethods(appConfig.AllowedMethods)
                                                .WithHeaders(appConfig.AllowedHeaders)
                                                .AllowCredentials();
                                                
                                              if (appConfig.AllowedOrigins?.Length > 0)
                                              {
                                                  builder
                                                    .WithOrigins(appConfig.AllowedOrigins);
                                              }
                                          });
                    });

            services
                .AddControllers(options =>
                {
                    options.Filters.Add(typeof(HttpResponseExceptionFilter));
                })
                .AddNewtonsoftJson(opts =>
                {
                    opts.SerializerSettings.Converters.Add(new StringEnumConverter());
                });

            services.AddApiVersioning(version =>
            {
                version.DefaultApiVersion = new ApiVersion(apiVersion.Major, apiVersion.Minor);
                version.AssumeDefaultVersionWhenUnspecified = true;
                version.ReportApiVersions = true;
                version.ApiVersionReader = new HeaderApiVersionReader("x-api-version");
            });

            services.AddSingleton<IPostConfigureOptions<NetAuthenticationOptions>, NetAuthenticationPostConfigureOptions>();
            services.AddSingleton<ITokenCache, TokenCache>();
            services.AddSingleton<INetSecurityTokenHandler, NetSecurityTokenHandler>();
            services.AddSingleton<ITokenJwt, TokenNet>();

            services.AddDistributedRedisCache(option =>
            {
                option.Configuration = appConfig.TokenCacheAddress;
                option.InstanceName = appConfig.TokenCacheInstance;
            });

            IServiceProvider serviceProvider = services.BuildServiceProvider();


            if (!(serviceProvider.GetService(typeof(ILoggerFactory))
                    is ILoggerFactory loggerFactory))
            {
                throw new ProviderServiceNotFoundException(nameof(ILoggerFactory));
            }

            ILogger logger = loggerFactory.CreateLogger(loggerType);

            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = NetBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = NetBearerDefaults.AuthenticationScheme;
            })
            .AddNetBearer(options =>
            {
                options.ValidTokenAsync = async (token, scheme) =>
                {
                    if (!(serviceProvider.GetService(typeof(INetSecurityTokenHandler))
                            is INetSecurityTokenHandler handler))
                    {
                        throw new ProviderServiceNotFoundException(nameof(INetSecurityTokenHandler));
                    }

                    if (!(serviceProvider.GetService(typeof(ITokenCache))
                            is ITokenCache tokenCache))
                    {
                        throw new ProviderServiceNotFoundException(nameof(ITokenCache));
                    }

                    NetResultValidToken result = await handler.ValidTokenAsync(token, appConfig.AuthTokenSecrect, tokenCache).ConfigureAwait(false);

                    if (!result.Sucess)
                    {
                        logger.DebugIsEnabled(() => string.Concat("ValidTokenAsync Error: ", result.Exception?.Message));
                    }

                    return result;
                };
            });
        }

        private static void AddApplicationServices(IServiceCollection services)
        {
            services.AddScoped<IUserApplication, UserApplication>();
            services.AddScoped<IAuthenticationApplication, AuthenticationApplication>();
            services.AddScoped<IEnvironmentApplication, EnvironmentApplication>();
        }

        private static void AddDomainServices(IServiceCollection services)
        {
            services.AddScoped<IEnvironmentService, EnvironmentService>();
            services.AddScoped<IUserService, UserService>();
        }

        private static void AddRepositoryServices(IServiceCollection services)
        {
            services.AddScoped<IEnvironmentRepository, EnvironmentRepository>();
            services.AddScoped<IUserRepository, UserRepository>();
        }

        private static void AddMapperConfiguration(IServiceCollection services)
        {
            var configuration = new MapperConfiguration(c => {
                c.AddProfile<EnvironmentMapper>();
                c.AddProfile<UserMapper>();
            });

            configuration.CreateMapper();

            services.AddSingleton<IMapper>(c => new Mapper(configuration));
        }
    }
}
