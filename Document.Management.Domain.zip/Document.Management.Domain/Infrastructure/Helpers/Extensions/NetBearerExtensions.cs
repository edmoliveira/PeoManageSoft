﻿using Document.Management.Business.Infrastructure.Tokens;
using Microsoft.AspNetCore.Authentication;
using System;

namespace Document.Management.Business.Infrastructure.Helpers.Extensions
{
    /// <summary>
    /// Authentication extension
    /// </summary>
    public static class NetBearerExtensions
    {
        #region Methods public

        /// <summary>
        /// Authentication extension method
        /// </summary>
        /// <param name="builder">Used to configure authentication</param>
        /// <param name="configureOptions"></param>
        /// <returns>Used to configure authentication</returns>
        public static AuthenticationBuilder AddNetBearer(this AuthenticationBuilder builder, Action<NetAuthenticationOptions> configureOptions)
        {
            return builder.AddScheme<NetAuthenticationOptions, NetAuthenticationHandler>(NetBearerDefaults.AuthenticationScheme, configureOptions);
        }

        #endregion
    }
}
