﻿using System.Data;

namespace Document.Management.Business.Infrastructure.ObjectRelationalMapper
{
    public interface IScope
    {
        void BeginTransaction();
        void CommitTransaction();
        void RollBackTransaction();
    }

    public interface IContentScope : IScope
    {
        IDbConnection Connection { get; set; }
        IDbTransaction DbTransaction { get; }
    }
}
