﻿using Document.Management.Business.Infrastructure.Helpers.Interfaces;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Document.Management.Business.Infrastructure.ObjectRelationalMapper
{

    public sealed class TransactionScopeOrm : ITransactionScope
    {
        private readonly IServiceProvider _provider;
        private readonly IAppConfig _appConfig;

        public TransactionScopeOrm(IServiceProvider provider, IAppConfig appConfig)
        {
            _provider = provider;
            _appConfig = appConfig;
        }

        public void Using(Action<IScope> action)
        {
            using DbConnection connection = CreateConnection();
            connection.Open();

            action(GetScope(connection));
        }

        public async Task UsingAsync(Func<IScope, Task> func)
        {
            using DbConnection connection = CreateConnection();
            await connection.OpenAsync();

            await func(GetScope(connection)).ConfigureAwait(false);
        }

        public T Using<T>(Func<IScope, T> func)
        {
            using DbConnection connection = CreateConnection();
            connection.Open();

            return func(GetScope(connection));
        }

        public async Task<T> UsingAsync<T>(Func<IScope, Task<T>> func)
        {
            using DbConnection connection = CreateConnection();
            await connection.OpenAsync();

            return await func(GetScope(connection)).ConfigureAwait(false);
        }

        private DbConnection CreateConnection()
        {
            return new SqlConnection(_appConfig.ConnectionString);
        }

        private IContentScope GetScope(IDbConnection connection)
        {
            IContentScope scope = _provider.GetService<IContentScope>();

            scope.Connection = connection;

            return scope;
        }
    }
}
