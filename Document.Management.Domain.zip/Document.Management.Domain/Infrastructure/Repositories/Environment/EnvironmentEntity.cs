﻿using Document.Management.Business.Infrastructure.Repositories.Interfaces;

namespace Document.Management.Business.Infrastructure.Repositories.Environment
{
    public class EnvironmentEntity: IEntity
    {
        public long Id { get; set; }
        public string Name { get; set; }

        public object GetInsertParameters()
        {
            return new
            {
                Name
            };
        }

        public object GetUpdateParameters()
        {
            return new
            {
                Id,
                Name
            };
        }
    }  
}
