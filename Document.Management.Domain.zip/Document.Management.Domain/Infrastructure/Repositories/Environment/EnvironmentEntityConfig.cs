﻿using System.Data;

namespace Document.Management.Business.Infrastructure.Repositories.Environment
{
    static class EnvironmentEntityConfig
    {
        public static (string sqlStatement, object parameterId, CommandType commandType) GetDeleteSqlStatement(long id)
        {
            return (sqlStatement: "[SP_DELETE_Environment]", parameterId: new { Id = id }, CommandType.StoredProcedure);
        }

        public static (string sqlStatement, CommandType commandType) GetInsertSqlStatement()
        {
            return (sqlStatement: "[SP_INSERT_Environment]", CommandType.StoredProcedure);
        }

        public static (string sqlStatement, object parameterId, CommandType commandType) GetSelectByIdSqlStatement(long id)
        {
            return (sqlStatement: "[SP_SELECT_BY_ID_Environment]", parameterId: new { Id = id }, CommandType.StoredProcedure);
        }

        public static (string sqlStatement, CommandType commandType) GetSelectSqlStatement()
        {
            return (sqlStatement: "[SP_SELECT_Environment]", CommandType.StoredProcedure);
        }

        public static (string sqlStatement, CommandType commandType) GetUpdateSqlStatement()
        {
            return (sqlStatement: "[SP_UPDATE_Environment]", CommandType.StoredProcedure);
        }
    }
}
