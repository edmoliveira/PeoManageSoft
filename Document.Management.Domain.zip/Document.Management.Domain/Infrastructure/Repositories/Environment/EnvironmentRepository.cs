﻿using Document.Management.Business.Infrastructure.Helpers.Extensions;
using Document.Management.Business.Infrastructure.ObjectRelationalMapper;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Document.Management.Business.Infrastructure.Repositories.Environment
{
    public sealed class EnvironmentRepository : IEnvironmentRepository
    {
        private readonly IDbContext _dbContext;
        /// <summary>
        /// Log
        /// </summary>
        private readonly ILogger<EnvironmentRepository> _logger;

        public EnvironmentRepository(IDbContext dbContext, ILogger<EnvironmentRepository> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        public async Task DeleteAsync(IScope scope, long id)
        {
            string methodName = nameof(DeleteAsync);

            _logger.LogBeginInformation(methodName);

            IContentScope contentScope = (IContentScope)scope;
            (string sqlStatement,
             object parameterId,
             CommandType commandType) = EnvironmentEntityConfig.GetDeleteSqlStatement(id);

            _ = await _dbContext.ExecuteAsync(
                contentScope.Connection,
                sqlStatement,
                parameterId,
                contentScope.DbTransaction,
                commandType
            ).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);
        }

        public async Task InsertAsync(IScope scope, EnvironmentEntity entity)
        {
            string methodName = nameof(InsertAsync);

            _logger.LogBeginInformation(methodName);

            IContentScope contentScope = (IContentScope)scope;
            (string sqlStatement,
             CommandType commandType) = EnvironmentEntityConfig.GetInsertSqlStatement();

            entity.Id = await _dbContext.ExecuteScalarAsync<object, long>(
                contentScope.Connection,
                sqlStatement,
                entity.GetInsertParameters(),
                contentScope.DbTransaction,
                commandType
            ).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);
        }

        public async Task<IEnumerable<EnvironmentEntity>> SelectAllAsync(IScope scope)
        {
            string methodName = nameof(SelectAllAsync);

            _logger.LogBeginInformation(methodName);

            IContentScope contentScope = (IContentScope)scope;
            (string sqlStatement,
             CommandType commandType) = EnvironmentEntityConfig.GetSelectSqlStatement();

            IEnumerable<EnvironmentEntity> result = await _dbContext.QueryAsync<EnvironmentEntity>(
                contentScope.Connection,
                sqlStatement,
                null,
                contentScope.DbTransaction,
                commandType
            ).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }

        public async Task<EnvironmentEntity> SelectByIdAsync(IScope scope, long id)
        {
            string methodName = nameof(SelectByIdAsync);

            _logger.LogBeginInformation(methodName);

            IContentScope contentScope = (IContentScope)scope;
            (string sqlStatement,
             object parameterId,
             CommandType commandType) = EnvironmentEntityConfig.GetSelectByIdSqlStatement(id);

            EnvironmentEntity result = await _dbContext.QueryFirstOrDefaultAsync<EnvironmentEntity>(
                contentScope.Connection,
                sqlStatement,
                parameterId,
                contentScope.DbTransaction,
                commandType
            ).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }

        public async Task UpdateAsync(IScope scope, EnvironmentEntity entity)
        {
            string methodName = nameof(UpdateAsync);

            _logger.LogBeginInformation(methodName);

            IContentScope contentScope = (IContentScope)scope;
            (string sqlStatement,
             CommandType commandType) = EnvironmentEntityConfig.GetUpdateSqlStatement();

            _ = await _dbContext.ExecuteAsync(
                contentScope.Connection,
                sqlStatement,
                entity.GetUpdateParameters(),
                contentScope.DbTransaction,
                commandType
            ).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);
        }
    }
}
