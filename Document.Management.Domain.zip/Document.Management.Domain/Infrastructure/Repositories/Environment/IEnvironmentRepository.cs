﻿using Document.Management.Business.Infrastructure.Repositories.Interfaces;

namespace Document.Management.Business.Infrastructure.Repositories.Environment
{
    public interface IEnvironmentRepository : IBaseRepository<EnvironmentEntity>
    {
    }
}
