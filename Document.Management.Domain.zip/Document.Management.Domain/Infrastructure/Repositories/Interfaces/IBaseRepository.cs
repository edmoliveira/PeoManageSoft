﻿using Document.Management.Business.Infrastructure.ObjectRelationalMapper;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Document.Management.Business.Infrastructure.Repositories.Interfaces
{
    public interface IBaseRepository<TEntity>
    {
        Task InsertAsync(IScope scope, TEntity entity);
        Task UpdateAsync(IScope scope, TEntity entity);
        Task DeleteAsync(IScope scope, long id);
        Task<TEntity> SelectByIdAsync(IScope scope, long id);
        Task<IEnumerable<TEntity>> SelectAllAsync(IScope scope);
    }
}
