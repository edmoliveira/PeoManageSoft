﻿namespace Document.Management.Business.Infrastructure.Repositories.Interfaces
{
    public interface IEntity
    {
        long Id { get; set; }

        object GetInsertParameters();
        object GetUpdateParameters();
    }
}
