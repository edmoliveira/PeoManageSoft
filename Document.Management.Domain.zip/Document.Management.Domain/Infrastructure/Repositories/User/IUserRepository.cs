﻿using Document.Management.Business.Infrastructure.ObjectRelationalMapper;
using Document.Management.Business.Infrastructure.Repositories.Interfaces;
using System.Threading.Tasks;

namespace Document.Management.Business.Infrastructure.Repositories.User
{
    public interface IUserRepository : IBaseRepository<UserEntity>
    {
        Task<UserEntity> SelectUserAsync(IScope scope, string username, string password);
        Task<bool> ChangePasswordAsync(IScope scope, string username, string oldPassword, string newPassword);
    }
}
