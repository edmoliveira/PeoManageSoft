﻿using Document.Management.Business.Infrastructure.Repositories.Interfaces;

namespace Document.Management.Business.Infrastructure.Repositories.User
{
    public class UserEntity: IEntity
    {
        public long Id { get; set; }
        public string User { get; set; }
        public string Password { get; set; }
        public int Role { get; set; }
        public string Name { get; set; }
        public string ShortName { get; set; }
        public string Title { get; set; }
        public string Department { get; set; }
        public string Email { get; set; }
        public string BussinessPhone { get; set; }
        public string MobilePhone { get; set; }
        public string Location { get; set; }

        public object GetInsertParameters()
        {
            return new 
            { 
                User,
                Password,
                Role,
                Name,
                ShortName,
                Title,
                Department,
                Email,
                BussinessPhone,
                MobilePhone,
                Location
            };
        }

        public object GetUpdateParameters()
        {
            return new
            {
                Id,
                User,
                Role,
                Name,
                ShortName,
                Title,
                Department,
                Email,
                BussinessPhone,
                MobilePhone,
                Location
            };
        }
    }
}
