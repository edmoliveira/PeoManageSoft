﻿using System.Data;

namespace Document.Management.Business.Infrastructure.Repositories.User
{
    static class UserEntityConfig
    {
        public static (string sqlStatement, object parameterId, CommandType commandType) GetDeleteSqlStatement(long id)
        {
            return (sqlStatement: "[SP_DELETE_User]", parameterId: new { Id = id }, CommandType.StoredProcedure);
        }

        public static (string sqlStatement, CommandType commandType) GetInsertSqlStatement()
        {
            return (sqlStatement: "[SP_INSERT_User]", CommandType.StoredProcedure);
        }

        public static (string sqlStatement, object parameterId, CommandType commandType) GetSelectByIdSqlStatement(long id)
        {
            return (sqlStatement: "[SP_SELECT_BY_ID_User]", parameterId: new { Id = id }, CommandType.StoredProcedure);
        }

        public static (string sqlStatement, CommandType commandType) GetSelectSqlStatement()
        {
            return (sqlStatement: "[SP_SELECT_User]", CommandType.StoredProcedure);
        }

        public static (string sqlStatement, CommandType commandType) GetUpdateSqlStatement()
        {
            return (sqlStatement: "[SP_UPDATE_User]", CommandType.StoredProcedure);
        }

        public static (string sqlStatement, object parameters, CommandType commandType) GetSelectUserSqlStatement(string username, string password)
        {
            return (sqlStatement: "[SP_SELECT_AUTH_User]", parameters: new { Username = username, Password = password }, CommandType.StoredProcedure);
        }

        public static (string sqlStatement, object parameters, CommandType commandType) GetUpdateChangePassSqlStatement(string username, string oldPassword, string newPassword)
        {
            return (sqlStatement: "[SP_UPDATE_CHANGE_PASS_User]", parameters: new {
                Username = username, 
                Password = oldPassword,
                NewPassword = newPassword
            }, CommandType.StoredProcedure);
        }
    }
}
