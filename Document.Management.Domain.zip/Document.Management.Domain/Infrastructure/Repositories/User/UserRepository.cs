﻿using Document.Management.Business.Infrastructure.Helpers.Extensions;
using Document.Management.Business.Infrastructure.ObjectRelationalMapper;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Document.Management.Business.Infrastructure.Repositories.User
{
    public sealed class UserRepository : IUserRepository
    {
        private readonly IDbContext _dbContext;
        /// <summary>
        /// Log
        /// </summary>
        private readonly ILogger<UserRepository> _logger;

        public UserRepository(IDbContext dbContext, ILogger<UserRepository> logger)
        {
            _dbContext = dbContext;
            _logger = logger;
        }

        public async Task DeleteAsync(IScope scope, long id)
        {
            string methodName = nameof(DeleteAsync);

            _logger.LogBeginInformation(methodName);

            IContentScope contentScope = (IContentScope)scope;
            (string sqlStatement,
             object parameterId,
             CommandType commandType) = UserEntityConfig.GetDeleteSqlStatement(id);

            _ = await _dbContext.ExecuteAsync(
                contentScope.Connection,
                sqlStatement,
                parameterId,
                contentScope.DbTransaction,
                commandType
            ).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);
        }

        public async Task InsertAsync(IScope scope, UserEntity entity)
        {
            string methodName = nameof(InsertAsync);

            _logger.LogBeginInformation(methodName);

            IContentScope contentScope = (IContentScope)scope;
            (string sqlStatement,
             CommandType commandType) = UserEntityConfig.GetInsertSqlStatement();

            entity.Id = await _dbContext.ExecuteScalarAsync<object, long>(
                contentScope.Connection,
                sqlStatement,
                entity.GetInsertParameters(),
                contentScope.DbTransaction,
                commandType
            ).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);
        }

        public async Task<IEnumerable<UserEntity>> SelectAllAsync(IScope scope)
        {
            string methodName = nameof(SelectAllAsync);

            _logger.LogBeginInformation(methodName);

            IContentScope contentScope = (IContentScope)scope;
            (string sqlStatement,
             CommandType commandType) = UserEntityConfig.GetSelectSqlStatement();

            IEnumerable<UserEntity> result = await _dbContext.QueryAsync<UserEntity>(
                contentScope.Connection,
                sqlStatement,
                null,
                contentScope.DbTransaction,
                commandType
            ).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }

        public async Task<UserEntity> SelectByIdAsync(IScope scope, long id)
        {
            string methodName = nameof(SelectByIdAsync);

            _logger.LogBeginInformation(methodName);

            IContentScope contentScope = (IContentScope)scope;
            (string sqlStatement,
             object parameterId,
             CommandType commandType) = UserEntityConfig.GetSelectByIdSqlStatement(id);

            UserEntity result = await _dbContext.QueryFirstOrDefaultAsync<UserEntity>(
                contentScope.Connection,
                sqlStatement,
                parameterId,
                contentScope.DbTransaction,
                commandType
            ).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }

        public async Task<UserEntity> SelectUserAsync(IScope scope, string username, string password)
        {
            string methodName = nameof(SelectUserAsync);

            _logger.LogBeginInformation(methodName);

            IContentScope contentScope = (IContentScope)scope;
            (string sqlStatement,
             object parameters,
             CommandType commandType) = UserEntityConfig.GetSelectUserSqlStatement(username, password);

            UserEntity result = await _dbContext.QueryFirstOrDefaultAsync<UserEntity>(
                contentScope.Connection,
                sqlStatement,
                parameters,
                contentScope.DbTransaction,
                commandType
            ).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return result;
        }

        public async Task UpdateAsync(IScope scope, UserEntity entity)
        {
            string methodName = nameof(UpdateAsync);

            _logger.LogBeginInformation(methodName);

            IContentScope contentScope = (IContentScope)scope;
            (string sqlStatement,
             CommandType commandType) = UserEntityConfig.GetUpdateSqlStatement();

            _ = await _dbContext.ExecuteAsync(
                contentScope.Connection,
                sqlStatement,
                entity.GetUpdateParameters(),
                contentScope.DbTransaction,
                commandType
            ).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);
        }

        public async Task<bool> ChangePasswordAsync(IScope scope, string username, string oldPassword, string newPassword)
        {
            string methodName = nameof(ChangePasswordAsync);

            _logger.LogBeginInformation(methodName);

            IContentScope contentScope = (IContentScope)scope;
            (string sqlStatement,
             object parameters,
             CommandType commandType) = UserEntityConfig.GetUpdateChangePassSqlStatement(username, oldPassword, newPassword);

            bool wasChanged = await _dbContext.ExecuteScalarAsync<object, bool>(
                contentScope.Connection,
                sqlStatement,
                parameters,
                contentScope.DbTransaction,
                commandType
            ).ConfigureAwait(false);

            _logger.LogEndInformation(methodName);

            return wasChanged;
        }
    }
}
