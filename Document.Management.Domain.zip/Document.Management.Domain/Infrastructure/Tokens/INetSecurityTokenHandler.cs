﻿using System.Threading.Tasks;

namespace Document.Management.Business.Infrastructure.Tokens
{
    /// <summary>
    ///  A NetSecurityTokenHandler designed for creating and validating Json Web Tokens.
    /// </summary>
    public interface INetSecurityTokenHandler
    {
        Task<NetResultValidToken> ValidTokenAsync(string token, string tokenSecrect, ITokenCache tokenCache);

        /// <summary>
        /// Creates a Json Web Token (JWT).
        /// </summary>
        /// <param name="tokenDescriptor">Contains some information which used to create a security token.</param>
        /// <param name="cache">Token cache</param>
        /// <returns>Security token</returns>
        Task<string> CreateTokenAsync(NetSecurityTokenDescriptor tokenDescriptor, ITokenCache tokenCache);
    }
}
