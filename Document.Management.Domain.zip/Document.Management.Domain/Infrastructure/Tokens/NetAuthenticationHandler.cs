﻿using Document.Management.Business.Infrastructure.Helpers;
using Document.Management.Business.Infrastructure.Helpers.Interfaces;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Primitives;
using System;
using System.Linq;
using System.Net.Http.Headers;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace Document.Management.Business.Infrastructure.Tokens
{
    /// <summary>
    /// An opinionated abstraction for implementing IAuthenticationHandler
    /// </summary>
    public sealed class NetAuthenticationHandler : AuthenticationHandler<NetAuthenticationOptions>
    {
        #region Fields private 

        /// <summary>
        /// Application Configuration
        /// </summary>
        private readonly IAppConfig _appConfig;

        #endregion

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the Document.Management.Business.Infrastructure.Tokens.NetAuthenticationHandler class.
        /// </summary>
        /// <param name="options">Used for notifications when TOptions instances change.</param>
        /// <param name="logger">
        /// Represents a type used to configure the logging system and create instances of
        /// Microsoft.Extensions.Logging.ILogger from the registered Microsoft.Extensions.Logging.ILoggerProviders.
        /// </param>
        /// <param name="encoder">Represents a URL character encoding.</param>
        /// <param name="clock">Abstracts the system clock to facilitate testing.</param>
        /// <param name="appConfig">Application Configuration</param>
        public NetAuthenticationHandler(
            IOptionsMonitor<NetAuthenticationOptions> options,
            ILoggerFactory logger,
            UrlEncoder encoder,
            ISystemClock clock, 
            IAppConfig appConfig)
            : base(options, logger, encoder, clock)
        {
            _appConfig = appConfig;
        }

        #endregion

        #region Methods protected

        /// <summary>
        /// Allows derived types to handle authentication.
        /// </summary>
        /// <returns>Contains the result of an Authenticate call</returns>
        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            try
            {
                NetResultValidToken result = new NetResultValidToken { Sucess = false };
                string headerKey = !_appConfig.WidowsAuthentication ? ApplicationResource.AuthorizationHeaderKey : ApplicationResource.XAuthorizationHeaderKey;

                if (Request.Headers.TryGetValue(headerKey, out StringValues authorization))
                {
                    AuthenticationHeaderValue token = AuthenticationHeaderValue.Parse(authorization.FirstOrDefault());

                    result = await Options.ValidTokenAsync(token.Parameter, Scheme).ConfigureAwait(false);
                }

                return result.Sucess ?
                    AuthenticateResult.Success(new AuthenticationTicket(result.Principal, Scheme.Name)) :
                    AuthenticateResult.Fail("Not Authorized");
            }
            catch (Exception exception)
            {
                Logger.LogError(exception, exception.Message);

                return AuthenticateResult.Fail("Not Authorized");
            }
        }

        #endregion
    }
}
