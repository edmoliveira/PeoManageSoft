﻿namespace Document.Management.Business.Infrastructure.Tokens
{
    /// <summary>
    /// Default values used by bearer authentication.
    /// </summary>
    public static class NetBearerDefaults
    {
        /// <summary>
        /// Default value for AuthenticationScheme property in the NetAuthenticationOptions   
        /// </summary>
        public const string AuthenticationScheme = "Bearer";
    }
}
