﻿namespace Document.Management.Business.Models.Application
{
    public sealed class ApplicationRequest
    {
        public string Name { get; set; }
    }
}
