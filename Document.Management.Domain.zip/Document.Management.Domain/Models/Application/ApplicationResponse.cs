﻿namespace Document.Management.Business.Models.Application
{
    class ApplicationResponse
    {
    }
}
