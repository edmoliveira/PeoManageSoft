﻿namespace Document.Management.Business.Models.ApplicationType
{
    public sealed class ApplicationTypeRequest
    {
        public string Name { get; set; }
    }
}
