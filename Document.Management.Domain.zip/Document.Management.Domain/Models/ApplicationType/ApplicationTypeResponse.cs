﻿namespace Document.Management.Business.Models.ApplicationType
{
    class ApplicationTypeResponse
    {
    }
}
