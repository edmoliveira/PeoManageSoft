﻿using Document.Management.Business.Models.TypeReleaseDocumentConfiguration;
using System.Collections.Generic;

namespace Document.Management.Business.Models.DetailedDescriptionReleaseDocumentConfig
{
    public sealed class DetailedDescriptionReleaseDocumentConfigRequest
    {
        public TypeReleaseDocumentConfigurationRequest TypeReleaseDocumentConfiguration { get; private set; }
        public string Title { get; private set; }

        public IEnumerable<string> Descriptions { get; private set; }
    }
}
