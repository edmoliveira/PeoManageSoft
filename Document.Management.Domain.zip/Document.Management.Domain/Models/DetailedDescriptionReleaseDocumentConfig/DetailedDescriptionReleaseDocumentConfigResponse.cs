﻿namespace Document.Management.Business.Models.DetailedDescriptionReleaseDocumentConfig
{
    class DetailedDescriptionReleaseDocumentConfigResponse
    {
    }
}
