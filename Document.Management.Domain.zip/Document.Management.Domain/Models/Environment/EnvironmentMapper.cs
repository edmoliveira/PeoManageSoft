﻿using AutoMapper;
using Document.Management.Business.Infrastructure.Repositories.Environment;

namespace Document.Management.Business.Models.Environment
{
    public class EnvironmentMapper: Profile
    {
        public EnvironmentMapper()
        {
            CreateMap<EnvironmentAddRequest, EnvironmentEntity>();
            CreateMap<EnvironmentUpdateRequest, EnvironmentEntity>();
            CreateMap<EnvironmentEntity, EnvironmentResponse>();
        }
    }
}
