﻿using System.ComponentModel.DataAnnotations;

namespace Document.Management.Business.Models.Environment
{
    public sealed class EnvironmentAddRequest
    {
        [Required]
        public string Name { get; set; }
    }

    public sealed class EnvironmentUpdateRequest
    {
        [Required]
        public long Id { get; set; }

        [Required]
        public string Name { get; set; }
    }    
}
