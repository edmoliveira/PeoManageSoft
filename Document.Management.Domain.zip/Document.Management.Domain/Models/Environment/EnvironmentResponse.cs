﻿namespace Document.Management.Business.Models.Environment
{
    public sealed class EnvironmentResponse
    {
        public long Id { get; set; }
        public string Name { get; set; }
    }
}
