﻿namespace Document.Management.Business.Models.ReleaseDocumentConfiguration
{
    public sealed class ReleaseDocumentConfigurationRequest
    {
    }
}
