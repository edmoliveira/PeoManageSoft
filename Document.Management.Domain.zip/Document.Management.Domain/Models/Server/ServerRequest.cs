﻿namespace Document.Management.Business.Models.Server
{
    public sealed class ServerRequest
    {
    }
}
