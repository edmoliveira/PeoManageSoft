﻿namespace Document.Management.Business.Models.Server
{
    class ServerResponse
    {
    }
}
