﻿using Document.Management.Business.Models.Server;
using Document.Management.Business.Models.TypeReleaseDocumentConfiguration;

namespace Document.Management.Business.Models.ServerTypeReleaseDocumentConfiguration
{
    public sealed class ServerTypeReleaseDocumentConfigurationRequest
    {
        public TypeReleaseDocumentConfigurationRequest TypeReleaseDocumentConfiguration { get; private set; }
        public ServerRequest Server { get; private set; }
        public string VariableName { get; private set; }
    }
}
