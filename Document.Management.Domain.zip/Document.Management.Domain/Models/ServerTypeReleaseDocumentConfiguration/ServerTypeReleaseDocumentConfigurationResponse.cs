﻿namespace Document.Management.Business.Models.ServerTypeReleaseDocumentConfiguration
{
    class ServerTypeReleaseDocumentConfigurationResponse
    {
    }
}
