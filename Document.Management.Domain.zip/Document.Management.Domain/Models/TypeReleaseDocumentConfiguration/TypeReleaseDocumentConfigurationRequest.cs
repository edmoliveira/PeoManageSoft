﻿using Document.Management.Business.Models.ApplicationType;
using Document.Management.Business.Models.ReleaseDocumentConfiguration;
using Document.Management.Business.Models.ServerTypeReleaseDocumentConfiguration;
using System.Collections.Generic;

namespace Document.Management.Business.Models.TypeReleaseDocumentConfiguration
{
    public sealed class TypeReleaseDocumentConfigurationRequest
    {
        public ReleaseDocumentConfigurationRequest ReleaseDocumentConfiguration { get; private set; }
        public ApplicationTypeRequest ApplicationType { get; private set; }
        public IEnumerable<ServerTypeReleaseDocumentConfigurationRequest> Servers { get; private set; }
    }
}
