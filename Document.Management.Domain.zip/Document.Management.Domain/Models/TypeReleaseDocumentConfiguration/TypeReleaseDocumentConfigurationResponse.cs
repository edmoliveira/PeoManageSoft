﻿namespace Document.Management.Business.Models.TypeReleaseDocumentConfiguration
{
    class TypeReleaseDocumentConfigurationResponse
    {
    }
}
