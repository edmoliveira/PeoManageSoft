﻿using System.ComponentModel.DataAnnotations;

namespace Document.Management.Business.Models.User
{
    public sealed class AuthenticateRequest
    {
        [Required]
        public string User { get; set; }
        [Required]
        public string Password { get; set; }
    }
}
