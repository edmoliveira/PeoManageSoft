﻿namespace Document.Management.Business.Models.User
{
    public sealed class AuthenticateResponse
    {
        public bool IsAuthenticated { get; set; }
        public string ErrorMessage { get; set; }
        public UserData Data { get; set; }
    }
}
