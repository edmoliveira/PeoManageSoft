﻿using System.ComponentModel.DataAnnotations;

namespace Document.Management.Business.Models.User
{
    public sealed class ChangePasswordRequest
    {
        [Required]
        public string User { get; set; }
        [Required]
        public string OldPassword { get; set; }
        [Required]
        public string NewPassword { get; set; }
    }
}
