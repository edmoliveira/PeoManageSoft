﻿namespace Document.Management.Business.Models.User
{
    public sealed class ChangePasswordResponse
    {
        public bool WasChanged { get; set; }
        public string ErrorMessage { get; set; }
    }
}
