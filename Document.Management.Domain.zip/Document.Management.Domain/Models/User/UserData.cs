﻿using Document.Management.Business.Infrastructure;

namespace Document.Management.Business.Models.User
{
    public sealed class UserData
    {
        public string Key { get; set; }
        public double ExpireSeconds { get; set; }
        public UserRole Role { get; set; }
        public string ShortName { get; set; }        
    }
}
