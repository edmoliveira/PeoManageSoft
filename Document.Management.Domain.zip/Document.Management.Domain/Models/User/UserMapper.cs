﻿using AutoMapper;
using Document.Management.Business.Infrastructure;
using Document.Management.Business.Infrastructure.Repositories.User;

namespace Document.Management.Business.Models.User
{
    public class UserMapper : Profile
    {
        public UserMapper()
        {
            CreateMap<UserAddRequest, UserEntity>()
                .ForMember(dest => dest.Role, opt => opt.MapFrom(src => (int)src.Role));
            CreateMap<UserUpdateRequest, UserEntity>()
                .ForMember(dest => dest.Role, opt => opt.MapFrom(src => (int)src.Role));
            CreateMap<UserEntity, UserResponse>()
                .ForMember(dest => dest.Role, opt => opt.MapFrom(src => (UserRole)src.Role));
        }
    }
}
