﻿using Document.Management.Business.Infrastructure;
using System.ComponentModel.DataAnnotations;

namespace Document.Management.Business.Models.User
{
    public sealed class UserAddRequest
    {
        [Required]
        public UserRole Role { get; set; }
        [Required]
        public string User { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public string RepeatPassword { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string ShortName { get; set; }
        [Required]
        public string Title { get; set; }
        [Required]
        public string Department { get; set; }
        [Required]
        public string Email { get; set; }
        public string BussinessPhone { get; set; }
        public string MobilePhone { get; set; }
        public string Location { get; set; }
    }

    public sealed class UserUpdateRequest
    {
        [Required]
        public UserRole Role { get; set; }
        [Required]
        public long Id { get; set; }

        [Required]
        public string User { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string ShortName { get; set; }
        [Required]
        public string Title { get; set; }
        [Required]
        public string Department { get; set; }
        [Required]
        public string Email { get; set; }
        public string BussinessPhone { get; set; }
        public string MobilePhone { get; set; }
        public string Location { get; set; }
    }
}
