﻿using Document.Management.Business.Infrastructure;

namespace Document.Management.Business.Models.User
{
    public sealed class UserResponse
    {
        public long Id { get; set; }
        public string User { get; set; }
        public UserRole Role { get; set; }
        public string Name { get; set; }
        public string ShortName { get; set; }
        public string Title { get; set; }
        public string Department { get; set; }
        public string Email { get; set; }
        public string BussinessPhone { get; set; }
        public string MobilePhone { get; set; }
        public string Location { get; set; }
    }
}
