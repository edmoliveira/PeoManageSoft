﻿namespace Document.Management.Business.Models.User
{
    public class UserSessionResponse
    {
        public bool IsAuthenticated { get; set; }
        public UserData Data { get; set; }
    }
}
